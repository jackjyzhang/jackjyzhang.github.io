'''
produce model generation
'''
import argparse
import os
from datasets import load_from_disk

from openai_complete import chat_completion

def extract_prompt_from_text(text, len_prompt):
    tokens = text.split(' ')
    tokens = tokens[:len_prompt]
    new_text = ' '.join(tokens)
    return new_text

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('data', type=str, help='path to huggingface dataset that has a column "text"')
    parser.add_argument('model', type=str, choices=['gpt-3.5-turbo', 'gpt-4'], help='str model name to generate continuation. huggingface/openai')
    parser.add_argument('--len_prompt', '-l', default=16, help='length of prompt')
    parser.add_argument('--max_tokens', type=int, default=256)

    args = parser.parse_args()
    name = args.data + f'-GEN-{args.model}-prompt{args.len_prompt}-max{args.max_tokens}'
    assert not os.path.exists(name), f'path {name} is nonempty, stopped'

    # NOTE: currently, no batching

    dataset = load_from_disk(args.data)
    
    def text_to_generated_text(ex):
        prompt = extract_prompt_from_text(ex['text'], args.len_prompt)
        response = chat_completion(prompt, args.model, args.max_tokens)
        ex['text'] = prompt.strip() + ' ' + response.strip()
        print(response)
        return ex

    new_dataset = dataset.map(text_to_generated_text)

    new_dataset.save_to_disk(name)

