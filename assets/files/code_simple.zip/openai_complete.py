import os
import openai
import time
import sys
openai.api_key = os.getenv("OPENAI_API_KEY")
MAX_TRIAL = 10
SLEEP_TIME = 5

# TODO: https://github.com/jd/tenacity
def chat_completion(prompt, model='gpt-3.5-turbo', max_tokens=512, **kwargs):
    trial = 0
    success = False
    while not success:
        trial += 1
        if trial > MAX_TRIAL:
            assert False, 'too many trials failed...'
        try:
            completion = openai.ChatCompletion.create(
                model=model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                max_tokens=max_tokens,
                **kwargs
            )
            success = True
        except openai.error.RateLimitError:
            print(f'RateLimitError, wait {SLEEP_TIME} seconds and retry (trial {trial})', file=sys.stderr)
            time.sleep(SLEEP_TIME)
        

    return completion.choices[0].message['content']
